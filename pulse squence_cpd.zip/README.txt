p5m4sp180.2_GEM 
= adiabatic decoupling sequence program (cpd) for 13C channel; Explicit version for sp31 power, you can use p5m4sp180.2 instead